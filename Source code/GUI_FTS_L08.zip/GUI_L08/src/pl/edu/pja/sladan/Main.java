package pl.edu.pja.sladan;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {

//        SwingUtilities.invokeLater(() -> new JButtonFrame());
//        SwingUtilities.invokeLater(() -> new JCheckBoxFrame());
//        SwingUtilities.invokeLater(() -> new JRadioButtonFrame());
//        SwingUtilities.invokeLater(() -> new JLabelFrame());
//        SwingUtilities.invokeLater(() -> new JTextFieldFrame());
//        SwingUtilities.invokeLater(() -> new JSplitPaneFrame());
//        SwingUtilities.invokeLater(() -> new JTabbedPaneFrame());

        SwingUtilities.invokeLater(() -> new JOptionPaneFrame());
    }

}
