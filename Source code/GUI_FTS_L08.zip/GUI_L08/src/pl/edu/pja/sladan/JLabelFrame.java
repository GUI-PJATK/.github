package pl.edu.pja.sladan;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class JLabelFrame extends JFrame {

    public JLabelFrame(){

        JLabel jLabel1 = new JLabel("Some text");
        JLabel jLabel2 = new JLabel("text2");
        JLabel jLabel3 = new JLabel("text3");

        jLabel1.setFont(new Font("Courier", Font.BOLD, 20));

        jLabel2.setIcon(new ImageIcon("ok.png"));

        jLabel3.setText("<html><h1><i>Aaabbb</i>  ccc</h1> ddd</html>");

        setLayout(new FlowLayout());

        add(jLabel1);
        add(jLabel2);
        add(jLabel3);

        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

}
