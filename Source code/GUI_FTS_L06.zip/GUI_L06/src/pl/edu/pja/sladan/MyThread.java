package pl.edu.pja.sladan;

public class MyThread extends Thread {

    @Override
    public void run() {
        System.out.println("First thread");
    }

}
