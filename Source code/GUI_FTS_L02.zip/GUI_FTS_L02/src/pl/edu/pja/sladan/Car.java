package pl.edu.pja.sladan;

public class Car extends Vehicle{

    public Car(String name) {
        super(name);
    }

    @Override
    public void showVehicleType() {
        System.out.println("Type: Car");
    }
}
