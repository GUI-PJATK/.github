package pl.edu.pja.sladan;

public class Oven implements ElectronicDevice {

    private boolean state;

    public Oven() {
        state = false;
    }

    public void turnOn(){
        if (state)
            System.out.println("The oven is already on");
        else
            System.out.println("The oven is now turned on");
    }

    public void turnOff(){
        if (state)
            System.out.println("The oven is now turned off");
        else
            System.out.println("The oven is already off");
    }
}
