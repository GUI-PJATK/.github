package pl.edu.pja.sladan;

public class Person {

    public String name;
    public String surname;

    public Person(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public void sayHello(){
        System.out.println("Hello " + name);
    }

    public void sayHello(String type){
        System.out.println(type + " " + name);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || this.getClass() != obj.getClass())
            return false;

        Person tmp = (Person) obj;
        boolean isEquals = true;

        if (tmp.name != null && this.name != null)
            isEquals = isEquals && tmp.name.equals(this.name);
        else if (!(tmp.name == null && this.name == null))
            isEquals = false;

        if (tmp.surname != null && this.surname != null)
            isEquals = isEquals && tmp.surname.equals(this.surname);
        else if (!(tmp.surname == null && this.surname == null))
            isEquals = false;

        return isEquals;
    }

    @Override
    public String toString() {
        return name + " " + surname;
    }
}
