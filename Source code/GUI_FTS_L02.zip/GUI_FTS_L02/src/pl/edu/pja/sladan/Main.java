package pl.edu.pja.sladan;

public class Main {

    public static void main(String[] args) {

        Person p1= new Person("Joanna", "King");
        Person p2= new Person("Joanna", "King");
        Employee e1 = new Employee("John", "Smith", 1600);

        System.out.println(p1);
        System.out.println(e1);

        System.out.println(p1.hashCode());
        System.out.println(p2.hashCode());
        System.out.println(p1.equals(p2));

        MyClass myClass = new MyClass();

        myClass.showText("GUI");
        myClass.showHelloWithText("GUI");

        // (argument list) -> {execution code}
//        Show s = (t) -> {
//            System.out.println("Hi " + t);
//        };
        Show s = t -> System.out.println("Hi " + t);

        s.showHelloWithText("John");

//        Vehicle vehicle = new Vehicle("something");
//        vehicle.showName();

        Car car = new Car("Volvo");
        car.showName();
        car.showVehicleType();

        Vehicle motorcycle = new Vehicle("Yamaha"){
            @Override
            public void showVehicleType() {
                System.out.println("Type: motorcycle");
            }
        };

        motorcycle.showName();
        motorcycle.showVehicleType();


        Computer c1 = new Computer();
        Oven o1 = new Oven();
        c1.turnOn();
        o1.turnOff();

        ElectronicDevice[] ed = new ElectronicDevice[2];
        ed[0] = o1;
        ed[1] = c1;

        for (int i = 0; i < ed.length; i++)
            ed[i].turnOff();

        ((Computer)ed[1]).replaceCPU();

    }

}
