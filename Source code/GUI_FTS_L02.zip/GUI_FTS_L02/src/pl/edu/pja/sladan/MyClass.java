package pl.edu.pja.sladan;

public class MyClass implements Show{

    @Override
    public void showHelloWithText(String text) {
        System.out.println("Hello " + text);
    }
}
