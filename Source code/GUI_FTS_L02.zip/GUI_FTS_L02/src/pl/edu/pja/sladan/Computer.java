package pl.edu.pja.sladan;

public class Computer implements ElectronicDevice{

    private boolean state;

    public Computer() {
        state = false;
    }

    public void replaceCPU(){
        System.out.println("Replaced");
    }

    public void turnOn(){
        if (state)
            System.out.println("The computer is already on");
        else
            System.out.println("The computer is now turned on");
    }

    public void turnOff(){
        if (state)
            System.out.println("The computer is now turned off");
        else
            System.out.println("The computer is already off");
    }
}
