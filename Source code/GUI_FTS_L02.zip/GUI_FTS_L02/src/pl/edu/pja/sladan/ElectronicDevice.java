package pl.edu.pja.sladan;

public interface ElectronicDevice {

    void turnOn();
    void turnOff();

}
