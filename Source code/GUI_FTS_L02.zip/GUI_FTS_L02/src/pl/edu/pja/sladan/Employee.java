package pl.edu.pja.sladan;

public class Employee extends Person{

    private double salary;

    public Employee(String name, String surname, double salary) {
        super(name, surname);
        this.salary = salary;
        sayHello();
        super.sayHello();
    }

    @Override
    public void sayHello() {
        System.out.println("Hi " + name + " " + surname);;
    }

    @Override
    public String toString() {
        return super.toString() + " " + salary;
    }
}
