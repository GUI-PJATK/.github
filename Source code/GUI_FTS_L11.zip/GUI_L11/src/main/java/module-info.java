module pl.edu.pja.sladan.gui_l11 {
    requires javafx.controls;
    requires javafx.fxml;


    opens pl.edu.pja.sladan.gui_l11 to javafx.fxml;
    exports pl.edu.pja.sladan.gui_l11;
}