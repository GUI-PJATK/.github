package pl.edu.pja.sladan;

public class Person {
    //public, private, protected
    private String name;
    private String surname;
    private double height;
    private int birthYear;
    private static int year = 2050;

    public Person(String name, String surname, double height, int birthYear){
        this.name = name;
        this.surname = surname;
        this.height = height;
        this.birthYear = birthYear;
    }

    public void sayHello(){
        System.out.println(name + " " + surname);
    }

    public String getName() {
        return name;
    }

    public static void setYear(int year) {
        Person.year = year;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name + " " + surname + " " + height + " " + birthYear;
    }
}
