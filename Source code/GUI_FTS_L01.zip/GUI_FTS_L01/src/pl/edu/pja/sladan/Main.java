package pl.edu.pja.sladan;

public class Main {

    public static void main(String[] args) {

        System.out.println("Hello world!");

        Person person1 = new Person("Joanna", "King", 182.5, 1994);

        person1.sayHello();

        System.out.println(person1);


        person1.setYear(2040);

        Person.setYear(2040);

        Vehicle volvo = new Vehicle("Volvo", MyColor.BLACK);
        System.out.println(volvo);

        Vehicle renault = new Vehicle("Renault", MyColor.RED);
        System.out.println(renault);

        System.out.println(MyColor.RED.isBasicColor());
        System.out.println(MyColor.WHITE.isBasicColor());

    }

}
