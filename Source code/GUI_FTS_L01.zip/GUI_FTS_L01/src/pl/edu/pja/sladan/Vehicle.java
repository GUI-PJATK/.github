package pl.edu.pja.sladan;

public class Vehicle {

    private String name;
    private MyColor color;

    public Vehicle(String name, MyColor color){
        this.name = name;
        this.color = color;
    }

    @Override
    public String toString() {
        return name + " " + color;
    }
}
