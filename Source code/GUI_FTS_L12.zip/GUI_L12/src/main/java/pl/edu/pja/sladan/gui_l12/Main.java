package pl.edu.pja.sladan.gui_l12;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        GridPane root = new GridPane();

        Label label = new Label("JavaFX");
        Button button = new Button("Button");
        TextArea textArea = new TextArea("TextArea");

//        textArea.setStyle("-fx-background-color: yellow");

        root.add(label, 0, 0);
        root.add(button, 0, 1);
        root.add(textArea, 0, 2);

        primaryStage.setTitle("GUI Lecture No. 12");

//        primaryStage.setScene(new Scene(root, 300, 275));
        Scene scene = new Scene(root, 300, 275);
        scene.getStylesheets().add("style.css");

        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}
