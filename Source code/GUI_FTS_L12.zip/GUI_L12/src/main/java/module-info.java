module pl.edu.pja.sladan.gui_l12 {
    requires javafx.controls;

    exports pl.edu.pja.sladan.gui_l12;
}