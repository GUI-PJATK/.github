package pl.edu.pja.sladan;

import pl.edu.pja.sladan.generics.*;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        Circle circle = new Circle(12);
        Square square = new Square(10);
        Triangle triangle = new Triangle(3, 5, 8);

        FigureBox<Circle> figureBox = new FigureBox<>(circle);
        FigureBox<Square> figureBox1 = new FigureBox<>(square);
        FigureBox<Triangle> figureBox2 = new FigureBox<>(triangle);

        System.out.println(figureBox);
        System.out.println(figureBox1);
        System.out.println(figureBox2);

        Inscibed<Square, Circle> inscibed = new Inscibed<>(square, circle);
        System.out.println(inscibed);

        wildcardStandard(figureBox1);

//        FigureBox<String> figureBox3 = new FigureBox("asd");

//        wildcardUpperBound(figureBox3);

        wildcardLowerBound(figureBox);
//        wildcardLowerBound(figureBox1);
//        wildcardLowerBound(figureBox2);


        List<String> arrayList = new ArrayList<>();
        List<String> linkedList = new LinkedList<>();

        linkedList.add("has");
        linkedList.add(0, "Joanna");
        linkedList.add("3");
        linkedList.add("cats");
        linkedList.add("Joanna");
        System.out.println(linkedList);
        System.out.println(linkedList.contains("cat"));
        System.out.println(linkedList.contains("Joanna"));
        System.out.println(linkedList.isEmpty());
        System.out.println(linkedList.size());
        System.out.println(linkedList.indexOf("Joanna"));
        linkedList.remove(2);
        System.out.println(linkedList);
        linkedList.remove("Joanna");
        System.out.println(linkedList);

        arrayList.addAll(linkedList);

        System.out.println(arrayList);

        Set<String> stringSet = new HashSet<>();

        stringSet.add("Joanna");
        stringSet.add("3");
        stringSet.add("Joanna");
        System.out.println(stringSet);

        stringSet.remove("Joanna");
        System.out.println(stringSet.isEmpty());
        System.out.println(stringSet.contains("3"));
        System.out.println(stringSet.size());

        System.out.println(stringSet);

        Map<String, String> cityCountry = new HashMap<>();

        cityCountry.put("Warsaw", "Poland");
        cityCountry.put("Cracow", "Poland");
        cityCountry.put("Oslo", "Norway");
        cityCountry.put("Berlin", "Germany");
        cityCountry.put("Paris", "France");

        System.out.println(cityCountry);

        System.out.println(cityCountry.containsKey("Cracow"));
        System.out.println(cityCountry.containsValue("Poland"));
        System.out.println(cityCountry.size());
        System.out.println(cityCountry.isEmpty());
        System.out.println(cityCountry.get("Warsaw"));
        System.out.println(cityCountry.get("asd"));
        System.out.println(cityCountry.getOrDefault("asd", "QWE"));

        cityCountry.remove("Cracow");
        cityCountry.remove("Warsaw", "Poland");

        System.out.println(cityCountry);

        for (String s : linkedList)
            System.out.println(s);

        for (String s : stringSet)
            System.out.println(s);

        for (String key : cityCountry.keySet())
            System.out.println(key);

        for (String val : cityCountry.values())
            System.out.println(val);

        for (String key : cityCountry.keySet())
            System.out.println(key + " " + cityCountry.get(key));

        for (Map.Entry<String, String> entry : cityCountry.entrySet()){
            System.out.println(entry.getKey() + " " + entry.getValue());
        }


    }

    public static void wildcardStandard(FigureBox<?> figureBox){
        System.out.println(figureBox);
    }

    public static void wildcardUpperBound(FigureBox<? extends Figure> figureBox){
        System.out.println(figureBox);
    }

    public static void wildcardLowerBound(FigureBox<? super Circle> figureBox){
        System.out.println(figureBox);
    }
}
