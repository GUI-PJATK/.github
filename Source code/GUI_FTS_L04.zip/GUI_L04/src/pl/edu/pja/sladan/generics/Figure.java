package pl.edu.pja.sladan.generics;

public interface Figure {

    double getPerimeter();

}
