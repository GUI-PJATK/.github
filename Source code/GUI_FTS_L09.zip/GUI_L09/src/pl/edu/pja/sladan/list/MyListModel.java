package pl.edu.pja.sladan.list;

import javax.swing.*;
import java.util.List;
import java.util.Vector;

public class MyListModel extends AbstractListModel {

    private List<String> names;

    public MyListModel(List<String> names){
        this.names = names;
    }

    @Override
    public int getSize() {
        return names.size();
    }

    @Override
    public Object getElementAt(int index) {
        return names.get(index);
    }
}
