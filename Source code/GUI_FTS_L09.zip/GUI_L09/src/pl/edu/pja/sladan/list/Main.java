package pl.edu.pja.sladan.list;

import pl.edu.pja.sladan.list.MyWindow;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MyWindow());
    }
}