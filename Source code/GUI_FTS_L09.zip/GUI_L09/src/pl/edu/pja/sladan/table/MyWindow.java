package pl.edu.pja.sladan.table;

import pl.edu.pja.sladan.list.MyListCellRenderer;
import pl.edu.pja.sladan.list.MyListModel;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class MyWindow extends JFrame {

    public MyWindow(){

        String[] columns = {"Name", "Surname", "Age"};

        Object[][] items = {
                {"Ann", "Smith", 30},
                {"John", "King", 23},
                {"Harry", "Edwards", 22}
        };

        MyTableModel myTableModel = new MyTableModel(items, columns);

        JTable jTable = new JTable();
        jTable.setModel(myTableModel);


        add(new JScrollPane(jTable));
        setSize(500, 500);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
