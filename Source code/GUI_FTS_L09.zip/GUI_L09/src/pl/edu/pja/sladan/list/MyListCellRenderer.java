package pl.edu.pja.sladan.list;

import javax.swing.*;
import java.awt.*;

public class MyListCellRenderer implements ListCellRenderer<String> {

    @Override
    public Component getListCellRendererComponent(JList<? extends String> list, String value, int index, boolean isSelected, boolean cellHasFocus) {
        JLabel jLabel = new JLabel(value);
        jLabel.setOpaque(true);

        if (index%2 == 0) {
            jLabel.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 16));
            jLabel.setBackground(Color.CYAN);
        }else
            jLabel.setFont(new Font(Font.DIALOG, Font.PLAIN, 12));

        return jLabel;
    }
}
