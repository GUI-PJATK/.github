package pl.edu.pja.sladan.list;

import javax.swing.*;
import java.util.Arrays;
import java.util.List;

public class MyWindow extends JFrame {

    public MyWindow(){

//        String[] items = {"Ann", "John", "Harry", "Joe"};

        List<String> items = Arrays.asList("Ann", "John", "Harry", "Joe");

        MyListModel myListModel = new MyListModel(items);

        JList jList = new JList();
        jList.setModel(myListModel);
        JScrollPane jScrollPane = new JScrollPane(jList);

        jList.setCellRenderer(new MyListCellRenderer());

        add(jScrollPane);
        setSize(200, 500);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
