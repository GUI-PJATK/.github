package pl.edu.pja.sladan;

import javax.swing.*;
import java.awt.event.*;

public class MyWindow extends JFrame {

    public MyWindow(){
        JButton jButton = new JButton("Click me!");
//        jButton.addActionListener(new MyActionListener());

        jButton.setActionCommand("Joanna");

        jButton.putClientProperty("greetingType", "Hello");
        jButton.putClientProperty("name", "Joanna");

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Clicked v2!");

                JButton b = (JButton)e.getSource();
                b.setText("2nd click");

                System.out.println("Hello " + b.getActionCommand() + "!");

                System.out.println(b.getClientProperty("greetingType") + " " + b.getClientProperty("name"));
            }
        });

        jButton.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("mouseClicked");
                System.out.println("Coordinates:\n" +
                        "X = " + e.getX() + "\n" +
                        "Y = " + e.getY());
            }

            @Override
            public void mousePressed(MouseEvent e) {
                System.out.println("mousePressed");
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                System.out.println("mouseReleased");
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                System.out.println("mouseEntered");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                System.out.println("mouseExited");
            }
        });

        jButton.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                System.out.println("keyTyped");
            }

            @Override
            public void keyPressed(KeyEvent e) {
                System.out.println("keyPressed");
                System.out.println("Pressed: " + e.getKeyChar());
            }

            @Override
            public void keyReleased(KeyEvent e) {
                System.out.println("keyReleased");
            }
        });

        add(jButton);

        pack();
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
