package pl.edu.pja.sladan;

public class Factorial {

    public static int iterative(int n){
        int result = 1;
        for (int i = 1; i <= n; i++)
            result *= i;
        return result;
    }

    public static int recursive(int n){
        if (n == 0)
            return 1;
        else
            return n * recursive(n - 1); // 5 * 4 * 3 * 2 * 1 * 1
    }

}
