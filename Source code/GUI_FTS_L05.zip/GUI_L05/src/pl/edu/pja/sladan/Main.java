package pl.edu.pja.sladan;

public class Main {
    public static void main(String[] args) {

        System.out.println(Factorial.iterative(5));
        System.out.println(Factorial.recursive(5));


        long timeStart = System.currentTimeMillis();
        System.out.println(Fibonacci.iterative(46));
        long timeStop = System.currentTimeMillis();
        System.out.println(timeStop - timeStart);

        timeStart = System.currentTimeMillis();
        System.out.println(Fibonacci.recursive(46));
        timeStop = System.currentTimeMillis();
        System.out.println(timeStop - timeStart);
    }



}