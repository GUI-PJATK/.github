package pl.edu.pja.sladan;

public class Fibonacci {

    public static int recursive(int n){
        if (n == 0)
            return 0;
        else if (n == 1)
            return 1;
        else
            return recursive(n-1) + recursive(n-2);
    }

    public static int iterative(int n){
        int f0 = 0;
        int f1 = 1;

        int tmp = 0;

        for (int i = 2; i <=n ;i++){
            tmp = f0+f1;
            f0 = f1;
            f1 = tmp;
        }

        return f1;
    }

}
