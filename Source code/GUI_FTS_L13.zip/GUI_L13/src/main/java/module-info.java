module pl.edu.pja.sladan.gui_l13 {
    requires javafx.controls;
    requires javafx.fxml;


    opens pl.edu.pja.sladan.gui_l13 to javafx.fxml;
    exports pl.edu.pja.sladan.gui_l13;
}