import java.io.*;

public class Main2 {
    public static void main(String[] args) throws IOException {

//        String s = new String("Some text");
        Person person = new Person("John", "Smith", 25);

        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;

        try {
            oos = new ObjectOutputStream(new FileOutputStream("oosFile.txt"));
            ois = new ObjectInputStream(new FileInputStream("oosFile.txt"));

//            oos.writeObject(s);
            oos.writeObject(person);

//            String text = (String) ois.readObject();

//            System.out.println(text);

            Person person2 = (Person)ois.readObject();

            System.out.println(person2);

        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            if (oos != null)
                oos.close();
        }


    }
}