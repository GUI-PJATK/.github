import java.io.*;

public class Main3 {
    public static void main(String[] args) throws IOException {

        BufferedReader br = null;
//        BufferedWriter bw = null;
        PrintWriter pw = null;

        try {
            br = new BufferedReader(new FileReader("file.txt"));
//            bw = new BufferedWriter(new FileWriter("bwFile.txt"));
            pw = new PrintWriter("pwFile.txt");

            String s;

            while ((s = br.readLine()) != null){
                System.out.println(s);
//                bw.write(s);
//                bw.newLine();
                pw.println(s);
            }


        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (br != null)
                br.close();
//            if (bw != null)
//                bw.close();
            if (pw != null)
                pw.close();
        }




    }
}