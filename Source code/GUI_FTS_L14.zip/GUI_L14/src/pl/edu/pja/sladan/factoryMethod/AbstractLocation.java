package pl.edu.pja.sladan.factoryMethod;

public abstract class AbstractLocation {

    public abstract Report generateReport();

}
