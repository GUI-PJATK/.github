package pl.edu.pja.sladan.flyweight;

public class SquareDimension {

    public int x;

    public SquareDimension(int x){
        this.x = x;
    }

}
