package pj.edu.pja.sladan;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {

//        new MyWindow1();

//        SwingUtilities.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//                new MyWindow1();
//            }
//        });

//        SwingUtilities.invokeLater(()->new MyWindow1());
//        SwingUtilities.invokeLater(()->new MyWindow2());
        SwingUtilities.invokeLater(()->new MyWindow3());

    }

}
